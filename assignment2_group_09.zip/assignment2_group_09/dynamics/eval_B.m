%% 
% Evalue the control matrix B
function B = eval_B()
B = reshape([-1.0,0.0,-1.0,0.0,1.0,-1.0],[3,2]);
end